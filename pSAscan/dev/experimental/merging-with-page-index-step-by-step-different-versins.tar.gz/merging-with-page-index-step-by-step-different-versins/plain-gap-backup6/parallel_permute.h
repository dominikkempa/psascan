#ifndef __PARALLEL_PERMUTE_H_INCLUDED
#define __PARALLEL_PERMUTE_H_INCLUDED

#include <cstdio>
#include <cstdlib>

#include <vector>
#include <stack>
#include <algorithm>
#include <thread>
#include <mutex>



template<typename T, unsigned pagesize_log>
void parallel_permute_aux(T *tab, T** index, std::mutex *mutexes,
    long length, long n_pages, long &selector, std::mutex &selector_mutex) {
  static const unsigned pagesize = (1U << pagesize_log);
  // Invariant: at all times, index[i] for any i points
  // to content that should be placed at i-th page of tab.
  while (true) {
    // Find starting point on some cycle.
    long start;
    while (true) {
      // Get the candidate using selector.
      std::unique_lock<std::mutex> lk(selector_mutex);
      while (selector < n_pages &&
          (index[selector] == tab + (selector << pagesize_log) ||
           index[selector] < tab || tab + length <= index[selector]))
          ++selector;

      // Exit, if the selector does not give any candidate.
      if (selector == n_pages) {
        lk.unlock();
        return;
      }

      // Unlock selector lock, allow other threads
      // to look for candidates in the meantime.
      start = selector++;
      lk.unlock();

      // Lock a candidate page and check if it's still good.
      // If yes, keep lock and proceed to process it.
      if (mutexes[start].try_lock() &&
          index[start] != tab + (start << pagesize_log) &&
          tab <= index[start] && index[start] < tab + length) break;
    }

    // Invariant: we have found a good candidate
    // page and have lock on mutexes[start].

    // First, we create temporary space for the
    // content of page at index[start] and move
    // the content at index[start] to that temp space.
    T *temp = new T[pagesize];
    std::copy(index[start], index[start] + pagesize, temp);
    std::swap(index[start], temp);
    mutexes[start].unlock();

    // We now have free space at temp. Keep placing there
    // elements from the cycle and moving temp pointer.
    do {
      // Invariant: temp points to a page inside tab.
      long next = (temp - tab) >> pagesize_log;
      std::unique_lock<std::mutex> lk(mutexes[next]);
      std::copy(index[next], index[next] + pagesize, temp);
      std::swap(index[next], temp);
      lk.unlock();
    } while (tab <= temp && temp < tab + length);
    delete[] temp;
  }
}

template<typename T, unsigned pagesize_log>
void parallel_permute(T *tab, long length, T** pageindex, long max_threads) {
  static const unsigned pagesize = (1U << pagesize_log);
  length -= length % pagesize;
  long n_pages = (length + pagesize - 1) >> pagesize_log;

  long selector = 0;
  std::mutex selector_mutex;
  std::mutex *mutexes = new std::mutex[n_pages];
  std::thread **threads = new std::thread*[max_threads];
  
  for (long i = 0; i < max_threads; ++i)
    threads[i] = new std::thread(parallel_permute_aux<T, pagesize_log>,
        tab, pageindex, mutexes, length, n_pages,
        std::ref(selector), std::ref(selector_mutex));

  for (long i = 0; i < max_threads; ++i) threads[i]->join();
  for (long i = 0; i < max_threads; ++i) delete threads[i];
  delete[] threads;
  delete[] mutexes;
}


#endif  // __PARALLEL_PERMUTE_H_INCLUDED
