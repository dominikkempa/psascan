#ifndef __CHANGE_GT_REFERENCE_POINT_H
#define __CHANGE_GT_REFERENCE_POINT_H

#include <cstring>
#include <algorithm>
#include <thread>

#include "bitvector.h"
#include "srank_aux.h"


//==============================================================================
// Compute range [microblock_beg..microblock_end) of bits in the output
// bitvector gt_out.
//==============================================================================
void change_gt_reference_point_aux(unsigned char *text, long text_length,
    long block_beg, long block_end, bitvector *gt_in, bitvector *gt_out) {
  // Void comparing the suffix with itself, the bit in gt_out
  // should be 0 anyway, so we don't have ot do anything.

  long block_size = block_end - block_beg;
  unsigned char *pat = text + block_beg, *txt = pat;
  long i = 1, el = 0L, s = 0L, p = 0L, r = 0L;
  long i_max = i, el_max = 0L, s_max = 0L, p_max = 0L, r_max = 0L;
  while (i < block_size) {
    // Compute lcp(text[left_block_beg..), text[left_block_beg+i..),
    // but compare not more than left_block_size symbols (we have gt_in
    // to resolve the long comparisons).
    while (block_beg + i + el < block_end && txt[i + el] == pat[el])
      next(pat, ++el, s, p, r);

    if (block_beg + i + el != text_length &&
        ((block_beg + i + el != block_end && txt[i + el] > pat[el]) ||
         (block_beg + i + el == block_end && !gt_in->get(block_beg + (block_size - 1 - el))))) gt_out->set(i);

    long j = i_max;
    if (el > el_max) {
      std::swap(el, el_max);
      std::swap(s, s_max);
      std::swap(p, p_max);
      std::swap(r, r_max);
      i_max = i;
    }

    if (el < 100) {
      ++i;
      el = 0;
    } else if (p > 0L && (p << 2) <= el && !memcmp(pat, pat + p, s)) {
      for (long k = 1L; k < std::min(block_size - i, p); ++k)
        if (gt_out->get(j + k)) gt_out->set(i + k);

      i += p;
      el -= p;
    } else {
      long h = (el >> 2) + 1L;
      for (long k = 1L; k < std::min(block_size - i, h); ++k)
        if (gt_out->get(j + k)) gt_out->set(i + k);

      i += h;
      el = 0;
      s = 0;
      p = 0;
    }
  }
}


//==============================================================================
// Given bitvector gt_in of length block_size such that for i = 0, ..,
// block_size - 1, gt_in[i] == 1 iff text[block_beg + i..) > text[block_end..)
// (where block_size = block_end - block_beg), compute bivctor gt_out of length
// block_size + 1such that for i = 0, .., block_size, gt_out[i] == 1 iff
// text[block_beg + i..) > text[block_beg..). Of course gt_out[0] is always 0.
//
// In other words, function takes the bitvector gt computed with respect to
// block end and from it computes the gt bitvector with respect to block start.
//==============================================================================
void change_gt_reference_point(unsigned char *text, long text_length,
    long block_beg, long block_end, bitvector *gt_in, bitvector* &gt_out,
    long max_threads) {
  // As usual, we make sure max_block_size is a multiple of 8 so that
  // no two threads will attempt to modify the bits inside the same byte.
  long block_size = block_end - block_beg;

  //----------------------------------------------------------------------------
  // STEP 1: allocate and zero-initialize (in parallel) the bitvector.
  //         Also, copy its last bit from the gt_in.
  //----------------------------------------------------------------------------
  gt_out = new bitvector(block_size + 1, max_threads);
  if (!gt_in->get(block_end - 1)) gt_out->set(block_size);


  //----------------------------------------------------------------------------
  // STEP 2: compute the remaining block_size bits.
  //----------------------------------------------------------------------------
  std::thread *th = new std::thread(change_gt_reference_point_aux,
        text, text_length, block_beg, block_end, gt_in, gt_out);
  th->join();
  delete th;


  // move the bits by hand.
  for (long j = 0; j < block_size; ++j) {
    gt_out->reset(j);
    if (gt_out->get(j + 1)) gt_out->set(j);
  }
  gt_out->reset(block_size);
}

#endif  // __CHANGE_GT_REFERENCE_POINT_H
