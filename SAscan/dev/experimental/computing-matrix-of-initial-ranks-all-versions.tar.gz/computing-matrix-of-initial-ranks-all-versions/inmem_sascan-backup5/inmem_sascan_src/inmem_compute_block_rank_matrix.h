// Note: this class creates more threads than blocks
// Right now I think the number of threads will be around
// 3 times the number of blocks. So here we have a similar
// situation as with divsufsort -- we use as many threads
// as there are blocks.

#ifndef __INMEM_COMPUTE_BLOCK_RANK_MATRIX
#define __INMEM_COMPUTE_BLOCK_RANK_MATRIX

#include <cstdio>
#include <cstdlib>
#include <string>

#include "bwtsa.h"
#include "background_block_reader.h"
#include "../../multifile.h"

namespace inmem_sascan_private {

// Return true iff text[i..length) > text[j..length).
// We access text via pattern class.
bool em_suffix_compare(std::string filename, long length, long i, long j) {
  pattern isuf(filename, i);
  pattern jsuf(filename, j);

  long lcp = 0L;
  while (i + lcp < length && j + lcp < length && isuf[lcp] == jsuf[lcp])
    ++lcp;

  return (j + lcp == length || (i + lcp < length && isuf[lcp] > jsuf[lcp]));
}

// Return true iff text[i..length) > text[j..length).
// i > j
bool compare_suffixes(unsigned char *text, long text_length, long i, long j,
    long text_beg, long supertext_length, std::string supertext_filename) {
  long text_end = text_beg + text_length;
  bool has_tail = (text_end != supertext_length);
  long lcp = 0L;
  while (i + lcp < text_length && text[i + lcp] == text[j + lcp]) ++lcp;

// Return !(i + lcp == text_length || text[i + lcp] < text[j + lcp]);
  if (i + lcp == text_length)
    return (has_tail && em_suffix_compare(supertext_filename, supertext_length, text_end, text_beg + j + lcp));
  else return text[i + lcp] > text[j + lcp];
}

// Return true iff text[i..) (but we always stop the comparison
// at text_length) is smaller than pat[0..pat_length).
bool lcp_compare_2(unsigned char *text, long text_length, pattern &pat, long pat_length,
    long gt_begin_length, long j, multifile_bit_stream_reader &rev_gt_begin_reader) {
  long lcp = 0;
  while (lcp < pat_length && j + lcp < text_length && pat[lcp] == text[j + lcp]) ++lcp;

  return (
      (lcp == pat_length) ||
      (j + lcp < text_length && pat[lcp] < text[j + lcp]) ||
      (j + lcp == text_length && !(rev_gt_begin_reader.access(gt_begin_length - (text_length - j))))
  );
}

// Return true iff text[i..) (but we always stop the comparison
// at text_length) is smaller than pat[0..pat_length).
bool lcp_compare_2_new(unsigned char *text, long text_length, pattern &pat, long pat_length,
    long gt_begin_length, long j, multifile_bit_stream_reader &rev_gt_begin_reader, long &lcp) {
  while (lcp < pat_length && j + lcp < text_length && pat[lcp] == text[j + lcp]) ++lcp;

  return (
      (lcp == pat_length) ||
      (j + lcp < text_length && pat[lcp] < text[j + lcp]) ||
      (j + lcp >= text_length && !(rev_gt_begin_reader.access(gt_begin_length - (text_length - j))))
  );
}


// Return true iff text[i..) (but we always stop the comparison
// at text_length) is smaller than pat[0..pat_length).
int lcp_compare_2_newer(unsigned char *text, long text_length, pattern &pat, long pat_length,
    long gt_begin_length, long j, multifile_bit_stream_reader &rev_gt_begin_reader, long &lcp) {
  while (lcp < pat_length && j + lcp < text_length && pat[lcp] == text[j + lcp]) ++lcp;

  if (lcp == pat_length) return 0;
  if ((j + lcp < text_length && pat[lcp] < text[j + lcp]) ||
      (j + lcp >= text_length && !(rev_gt_begin_reader.access(gt_begin_length - (text_length - j)))))
    return -1;
  else return 1;
}


// XXX add comments here
// XXX properly test this function
template<typename saidx_t>
void refine_range(unsigned char *text, long text_length,                       // text info
    long text_beg, long supertext_length, std::string /*supertext_filename*/,  // supertext info
    long block_beg, long /*block_end*/, bwtsa_t<saidx_t> *block_psa,           // block info
    long left, long right,                                                     // range
    multifile *tail_gt_begin_reversed,                                         // gt_begin for tail
    long old_pat_length, long pat_length, pattern &pat,                        // data about pattern
    long &newleft, long &newright) {                                           // OUTPUT: new range
  long text_end = text_beg + text_length;
  long gt_begin_length = supertext_length - text_end;
  multifile_bit_stream_reader reader(tail_gt_begin_reversed);

  // First, we implement it naively.
  newleft = left;
  long temp_min_lcp = old_pat_length;
  while (newleft < right && lcp_compare_2_newer(text, text_length, pat, pat_length,
        gt_begin_length, block_beg + block_psa[newleft].sa, reader, temp_min_lcp) > 0) {
    ++newleft;
    temp_min_lcp = old_pat_length;
  }

  newright = newleft;
  while (newright < right && lcp_compare_2_newer(text, text_length, pat, pat_length,
        gt_begin_length, block_beg + block_psa[newright].sa, reader, temp_min_lcp) == 0) {
    ++newright;
    temp_min_lcp = old_pat_length;
  }
}


#if 0
template<typename saidx_t>
void compute_matrix_last_column_aux(unsigned char *text, long text_length, long text_beg,
    long supertext_length, std::string supertext_filename, long block_beg, long block_end, 
    bwtsa_t<saidx_t> *block_psa, multifile *tail_gt_begin_reversed, long &result) {
  long text_end = text_beg + text_length;
  long block_size = block_end - block_beg;

  pattern pat(supertext_filename, text_end);
  long pat_length = supertext_length - text_end;

  multifile_bit_stream_reader reader(tail_gt_begin_reversed);

  long left = -1L;
  long right = block_size;
  while (left + 1 != right) {
    long mid = (left + right) / 2;
    if (lcp_compare_2(text, text_length, pat, pat_length, text_end, supertext_length,
       block_beg + block_psa[mid].sa, reader)) right = mid;
    else left = mid;
  }

  result = right;
}
#else
#if 0
template<typename saidx_t>
void compute_matrix_last_column_aux(unsigned char *text, long text_length, long text_beg,
    long supertext_length, std::string supertext_filename, long block_beg, long block_end, 
    bwtsa_t<saidx_t> *block_psa, multifile *tail_gt_begin_reversed, long &result) {
  long text_end = text_beg + text_length;
  long gt_begin_length = supertext_length - text_end;
  long block_size = block_end - block_beg;

  pattern pat(supertext_filename, text_end);
  long pat_length = supertext_length - text_end;

  multifile_bit_stream_reader reader(tail_gt_begin_reversed);

  long left = -1L;
  long right = block_size;
  while (left + 1 != right) {
    long mid = (left + right) / 2;
    if (lcp_compare_2(text, text_length, pat, pat_length, gt_begin_length,
       block_beg + block_psa[mid].sa, reader)) right = mid;
    else left = mid;
  }

  result = right;
}
#else
template<typename saidx_t>
void compute_matrix_last_column_aux(unsigned char *text, long text_length, long text_beg,
    long supertext_length, std::string supertext_filename, long block_beg, long block_end,
    bwtsa_t<saidx_t> *block_psa, multifile *tail_gt_begin_reversed, long &result) {
  long text_end = text_beg + text_length;
  long gt_begin_length = supertext_length - text_end;
  long block_size = block_end - block_beg;

  pattern pat(supertext_filename, text_end);
  long pat_length = supertext_length - text_end;

  // Ver 1.
  multifile_bit_stream_reader reader(tail_gt_begin_reversed);

  long left = -1L;
  long right = block_size;
  long llcp = 0L, rlcp = 0L;

  while (left + 1 != right) {
    long mid = (left + right) / 2;
    long lcp = std::min(llcp, rlcp);

    if (lcp_compare_2_new(text, text_length, pat, pat_length, gt_begin_length,
          block_beg + block_psa[mid].sa, reader, lcp)) {
      right = mid;
      rlcp = lcp;
    } else {
      left = mid;
      llcp = lcp;
    }
  }

  result = right;




  // Ver 2.
  long newleft = 0L, newright = 0L;
  refine_range<saidx_t>(text, text_length,
      text_beg, supertext_length, supertext_filename,
      block_beg, block_end, block_psa,
      0L, block_size,
      tail_gt_begin_reversed,
      0L, pat_length, pat,
      newleft, newright);

//  result = newleft;
  if (newleft != result) {
    fprintf(stdout, "\nI found a difference for:\n");
    fprintf(stdout, "\ttext = ");
    for (long j = 0; j < text_length; ++j)
      fprintf(stdout, "%c", text[j]);
    fprintf(stdout, "\n");
    fprintf(stdout, "\ttext_length = %ld\n", text_length);
    fprintf(stdout, "\tblock_beg = %ld, block_end = %ld\n", block_beg, block_end);
    fprintf(stdout, "\tsupertext_length = %ld, text_beg = %ld\n", supertext_length, text_beg);
    fprintf(stdout, "\tpat = ");
    for (long j = 0; j < pat_length; ++j)
      fprintf(stdout, "%c", pat[j]);
    fprintf(stdout, "\n");
    fprintf(stdout, "\tblock_psa: ");
    for (long j = 0; j < block_size; ++j)
      fprintf(stdout, "%ld ", (long)block_psa[j].sa);
    fprintf(stdout, "\n");
    fprintf(stdout, "\tresult = %ld\n", result);
    fprintf(stdout, "\tnewleft = %ld, newright = %ld\n", newleft, newright);

    std::exit(EXIT_FAILURE);
  }
}
#endif
#endif

template<typename saidx_t, unsigned pagesize_log>
void compute_block_rank_matrix(unsigned char *text, long text_length, 
    bwtsa_t<saidx_t> *bwtsa, long max_block_size, long /*max_threads*/,
    long text_beg, long supertext_length, std::string supertext_filename,
    multifile * tail_gt_begin_reversed, long **block_rank_matrix) {
  long text_end = text_beg + text_length;
  long tail_length = supertext_length - text_end;
  bool has_tail = (text_end != supertext_length);
  long n_blocks = (text_length + max_block_size - 1) / max_block_size;

  // XXX we should actually start the reader even earlier (before divsufsort).
  long next_block_size = std::min(text_length, tail_length);
  background_block_reader *reader = new background_block_reader(supertext_filename, text_end, next_block_size);

  //---------------------------------------------------------------------------
  // STEP 1: compute the last column of the matrix.
  //---------------------------------------------------------------------------
  if (!has_tail) {
    for (long j = 0; j + 1 < n_blocks; ++j)
      block_rank_matrix[j][n_blocks - 1] = 0;
  } else {
#if 0
    fprintf(stderr, "\nError in compute_block_rank_matrix: this is currently not implemented!\n");
    std::exit(EXIT_FAILURE);
#else
#if 0
    pattern pat(supertext_filename, text_end);
    long pat_length = supertext_length - text_end;

    multifile_bit_stream_reader reader(tail_gt_begin_reversed);

    for (long j = 0; j + 1 < n_blocks; ++j) {
      long block_end = text_length - (n_blocks - 1 - j) * max_block_size;
      long block_beg = std::max(0L, block_end - max_block_size);
      long block_size = block_end - block_beg;

      bwtsa_t<saidx_t> *block_psa = bwtsa + block_beg;

      long left = -1L;
      long right = block_size;

      while (left + 1 != right) {
        long mid = (left + right) / 2;
        if (lcp_compare_2(text, text_length, pat, pat_length, text_end, supertext_length,
          block_beg + block_psa[mid].sa, reader)) right = mid;
        else left = mid;
      }

      block_rank_matrix[j][n_blocks - 1] = right;
    }
#else
    std::thread **threads = new std::thread*[n_blocks - 1];
    for (long t = 0; t + 1 < n_blocks; ++t) {
      long block_end = text_length - (n_blocks - 1 - t) * max_block_size;
      long block_beg = std::max(0L, block_end - max_block_size);
      bwtsa_t<saidx_t> *block_psa = bwtsa + block_beg;

      threads[t] = new std::thread(compute_matrix_last_column_aux<saidx_t>,
          text, text_length, text_beg, supertext_length, supertext_filename,
          block_beg, block_end, block_psa, tail_gt_begin_reversed,
          std::ref(block_rank_matrix[t][n_blocks - 1]));
    }

    for (long t = 0; t + 1 < n_blocks; ++t) threads[t]->join();
    for (long t = 0; t + 1 < n_blocks; ++t) delete threads[t];
    delete[] threads;
#endif
#endif
  }

  //---------------------------------------------------------------------------
  // STEP 2: compute the remaining elements of the matrix, that is,
  //   block_rank_matrix[i][j] for 0 <= i < j < n_blocks - 1.
  //---------------------------------------------------------------------------

  // XXX for now we do it sequentially.
  for (long i = 0; i < n_blocks; ++i) {
    long block_end = text_length - (n_blocks - 1 - i) * max_block_size;
    long block_beg = std::max(0L, block_end - max_block_size);
    long block_size = block_end - block_beg;
    bwtsa_t<saidx_t> *block_psa = bwtsa + block_beg;

    for (long j = i + 1; j + 1 < n_blocks; ++j) {
      long suf_start = text_length - (n_blocks - 1 - j) * max_block_size;

      // Binary search.
      long left = -1;
      long right = block_size;
      while (left + 1 != right) {  // while range size is > 1.
        // Invariant: the answer is in the range (left, right].
        long mid = (left + right) / 2;
        if (compare_suffixes(text, text_length, suf_start, block_beg + block_psa[mid].sa,
              text_beg, supertext_length, supertext_filename)) {
          left = mid;
        } else {
          right = mid;
        }
      }

      // The answer is 'right'.
      block_rank_matrix[i][j] = right;
    }
  }

  reader->stop();
  delete reader;
}

}  // inmem_sascan_private

#endif  // __INMEM_COMPUTE_BLOCK_RANK_MATRIX
