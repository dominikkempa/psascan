// Note: this class creates more threads than blocks
// Right now I think the number of threads will be around
// 3 times the number of blocks. So here we have a similar
// situation as with divsufsort -- we use as many threads
// as there are blocks.

#ifndef __INMEM_COMPUTE_BLOCK_RANK_MATRIX
#define __INMEM_COMPUTE_BLOCK_RANK_MATRIX

#include <cstdio>
#include <cstdlib>
#include <string>

#include "bwtsa.h"
#include "background_block_reader.h"
#include "../../multifile.h"

namespace inmem_sascan_private {

// Return true iff text[i..length) > text[j..length).
// We access text via pattern class.
bool em_suffix_compare(std::string filename, long length, long i, long j) {
  pattern isuf(filename, i);
  pattern jsuf(filename, j);

  long lcp = 0L;
  while (i + lcp < length && j + lcp < length && isuf[lcp] == jsuf[lcp])
    ++lcp;

  return (j + lcp == length || (i + lcp < length && isuf[lcp] > jsuf[lcp]));
}

// Return true iff text[i..length) > text[j..length).
// i > j
bool compare_suffixes(unsigned char *text, long text_length, long i, long j,
    long text_beg, long supertext_length, std::string supertext_filename) {
  long text_end = text_beg + text_length;
  bool has_tail = (text_end != supertext_length);
  long lcp = 0L;
  while (i + lcp < text_length && text[i + lcp] == text[j + lcp]) ++lcp;

  if (i + lcp == text_length)
    return (has_tail && em_suffix_compare(supertext_filename, supertext_length, text_end, text_beg + j + lcp));
  else return text[i + lcp] > text[j + lcp];
}

int lcp_compare_2(unsigned char *text, long text_length, unsigned char *pat, long pat_length,
    long gt_begin_length, long j, multifile_bit_stream_reader &rev_gt_begin_reader, long &lcp) {
  while (lcp < pat_length && j + lcp < text_length && pat[lcp] == text[j + lcp]) ++lcp;

  if (lcp == pat_length) return 0;
  if ((j + lcp < text_length && pat[lcp] < text[j + lcp]) ||
      (j + lcp >= text_length && !(rev_gt_begin_reader.access(gt_begin_length - (text_length - j)))))
    return -1;
  else return 1;
}

int lcp_compare_2_simple(unsigned char *text, unsigned char *pat, long pat_length, long j, long &lcp) {
  while (lcp < pat_length && pat[lcp] == text[j + lcp]) ++lcp;

  if (lcp == pat_length) return 0;
  else if (pat[lcp] < text[j + lcp]) return -1;
  else return 1;
}


template<typename saidx_t>
void refine_range(unsigned char *text,
    long block_beg, bwtsa_t<saidx_t> *block_psa,
    long left, long right,
    long old_pat_length, long pat_length, unsigned char *pat,
    long &newleft, long &newright) {  // output
  long low = left - 1;
  long high = right;
  long llcp = old_pat_length;
  long rlcp = old_pat_length;

  // static const long min_discrepancy = /*(1L << 16)*/1L;
  // static const long balancing_constant = /*64L*/1L;
  // XXX replace the above
  long min_discrepancy = utils::random_long(0L, 10L);
  long balancing_constant = utils::random_long(1L, 10L);

  while (low + 1 != high) {
    // Invariant: newleft is in the range (low, high].

    // Compute mid.
    // Valid values for mid are: low + 1, .., high - 1.
    long mid = 0L;
    if (llcp + min_discrepancy < rlcp) {
      // Choose the pivot that split the range into two parts of sizes
      // with ratio equal to logd / d.
      long d = rlcp - llcp;
      long logd = utils::log2ceil(d);
      mid = low + 1 + ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
    } else if (rlcp + min_discrepancy < llcp) {
      long d = llcp - rlcp;
      long logd = utils::log2ceil(d);
      mid = high - 1 - ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
    } else {
      // Discrepancy between lcp values is small, use standard binary search.
      mid = (low + high) / 2;
    }

    long lcp = std::min(llcp, rlcp);

    if (lcp_compare_2_simple(text, pat, pat_length, block_beg + block_psa[mid].sa, lcp) <= 0) {
      high = mid;
      rlcp = lcp;
    } else {
      low = mid;
      llcp = lcp;
    }
  }

  newleft = high;

  if (rlcp < pat_length) newright = newleft;
  else {
    high = right;
    rlcp = old_pat_length;

    while (low + 1 != high) {
      // Invariant: newright is in the range (low, high].

      // Compute mid.
      // Valid values for mid are: low + 1, .., high - 1.
      long mid = 0L;
      if (llcp + min_discrepancy < rlcp) {
        // Choose the pivot that split the range into two parts of sizes
        // with ratio equal to logd / d.
        long d = rlcp - llcp;
        long logd = utils::log2ceil(d);
        mid = low + 1 + ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
      } else if (rlcp + min_discrepancy < llcp) {
        long d = llcp - rlcp;
        long logd = utils::log2ceil(d);
        mid = high - 1 - ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
      } else {
        // Discrepancy between lcp values is small, use standard binary search.
        mid = (low + high) / 2;
      }

      long lcp = std::min(llcp, rlcp);

      if (lcp_compare_2_simple(text, pat, pat_length, block_beg + block_psa[mid].sa, lcp) < 0) {
        high = mid;
        rlcp = lcp;
      } else {
        low = mid;
        llcp = lcp;
      }
    }

    newright = high;
  }
}


template<typename saidx_t>
void refine_range(unsigned char *text, long text_length,
    long tail_gt_begin_reversed_length,
    long block_beg, bwtsa_t<saidx_t> *block_psa,
    long left, long right,
    multifile *tail_gt_begin_reversed,
    long old_pat_length, long pat_length, unsigned char *pat,
    long &newleft, long &newright) {  // output
  multifile_bit_stream_reader reader(tail_gt_begin_reversed);

  long low = left - 1;
  long high = right;
  long llcp = old_pat_length;
  long rlcp = old_pat_length;

  // static const long min_discrepancy = /*(1L << 16)*/1L;
  // static const long balancing_constant = /*64L*/1L;
  // XXX replace the above
  long min_discrepancy = utils::random_long(0L, 10L);
  long balancing_constant = utils::random_long(1L, 10L);

  while (low + 1 != high) {
    // Invariant: newleft is in the range (low, high].

    // Compute mid.
    // Valid values for mid are: low + 1, .., high - 1.
    long mid = 0L;
    if (llcp + min_discrepancy < rlcp) {
      // Choose the pivot that split the range into two parts of sizes
      // with ratio equal to logd / d.
      long d = rlcp - llcp;
      long logd = utils::log2ceil(d);
      mid = low + 1 + ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
    } else if (rlcp + min_discrepancy < llcp) {
      long d = llcp - rlcp;
      long logd = utils::log2ceil(d);
      mid = high - 1 - ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
    } else {
      // Discrepancy between lcp values is small, use standard binary search.
      mid = (low + high) / 2;
    }

    long lcp = std::min(llcp, rlcp);

    if (lcp_compare_2(text, text_length, pat, pat_length, tail_gt_begin_reversed_length,
          block_beg + block_psa[mid].sa, reader, lcp) <= 0) {
      high = mid;
      rlcp = lcp;
    } else {
      low = mid;
      llcp = lcp;
    }
  }

  newleft = high;

  if (rlcp < pat_length) newright = newleft;
  else {
    high = right;
    rlcp = old_pat_length;

    while (low + 1 != high) {
      // Invariant: newright is in the range (low, high].

      // Compute mid.
      // Valid values for mid are: low + 1, .., high - 1.
      long mid = 0L;
      if (llcp + min_discrepancy < rlcp) {
        // Choose the pivot that split the range into two parts of sizes
        // with ratio equal to logd / d.
        long d = rlcp - llcp;
        long logd = utils::log2ceil(d);
        mid = low + 1 + ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
      } else if (rlcp + min_discrepancy < llcp) {
        long d = llcp - rlcp;
        long logd = utils::log2ceil(d);
        mid = high - 1 - ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
      } else {
        // Discrepancy between lcp values is small, use standard binary search.
        mid = (low + high) / 2;
      }

      long lcp = std::min(llcp, rlcp);

      if (lcp_compare_2(text, text_length, pat, pat_length, tail_gt_begin_reversed_length,
            block_beg + block_psa[mid].sa, reader, lcp) < 0) {
        high = mid;
        rlcp = lcp;
      } else {
        low = mid;
        llcp = lcp;
      }
    }

    newright = high;
  }

  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // NOTE: the range returned by this function is NOT the range of suffixes
  // starting in the block that has pat[0..pat_length) as a prefix. This would
  // only be the case, if we didn't use gt_begin for the tail.
  //
  // Instead what we get is a subrange of the above. More specifically, we get
  // the range of suffixes starting inside the block that have pat[0..pat_length)
  // as a prefix *and we could not determine whether they are larger than the
  // whole pattern (of length tail_gt_begin_reversed_legth) or not*.
  //
  // This is because we stop the symbol comparisons (when computing lcp value)
  // at the end of the text and then use gt_begin for the tail. This may cause
  // the we classify the suffix with pat[0..pat_length) as a prefix already at
  // this point as larger than the whole pattern because gt_begin encodes that
  // information.
  //
  // This effect makes thus function difficult to debug, because there is no
  // well defined output of the range refinement.
  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
}



//=============================================================================
// Variant 1: compute primary and secondary range for col other than the last
// one and second to last one.
//=============================================================================
template<typename saidx_t>
void compute_ranges_1(unsigned char *text, long text_length, bwtsa_t<saidx_t> *bwtsa, long max_block_size,
    std::pair<long, long> **primary_range, std::pair<long, long> **secondary_range, long row, long column) {
  long n_blocks = (text_length + max_block_size - 1) / max_block_size;
  long block_end = text_length - (n_blocks - 1 - row) * max_block_size;
  long block_begin = std::max(0L, block_end - max_block_size);
  long block_size = block_end - block_begin;
  long pat_start = text_length - (n_blocks - 1 - column) * max_block_size;
  unsigned char *pat = text + pat_start;
  bwtsa_t<saidx_t> *block_psa = bwtsa + block_begin;


  // Check that 0 <= row < column < n_blocks - 2 and pat_start + 2 * max_block_size <= text_length.
  if (0 > row || row >= column || column >= n_blocks - 2 || pat_start + 2L * max_block_size > text_length) {
    fprintf(stdout, "\nError: invariant in compute_ranges_1 failed.\n");
    std::fflush(stdout);
    std::exit(EXIT_FAILURE);
  }


  long left = 0L;
  long right = block_size;
  long cur_pat_length = 0L;


  // Compute the primary range.
  {
    long newleft = 0L;
    long newright = 0L;
    long new_pat_length = max_block_size;
    refine_range(text, block_begin, block_psa, left, right,
        cur_pat_length, new_pat_length, pat, newleft, newright);
    left = newleft;
    right = newright;
    cur_pat_length = new_pat_length;
  }
  primary_range[row][column] = std::make_pair(left, right);


  // Verify the primary range.
  {
    long smaller = 0L;
    long equal = 0L;
    for (long j = block_begin; j < block_end; ++j) {
      long lcp = 0L;
      while (lcp < max_block_size && text[j + lcp] == pat[lcp]) ++lcp;
      if (lcp == max_block_size) ++equal;
      else if (text[j + lcp] < pat[lcp]) ++smaller;
    }
    long check_left = smaller;
    long check_right = smaller + equal;
    if (primary_range[row][column] != std::make_pair(check_left, check_right)) {
      fprintf(stdout, "\nError: incorrect primary range!\n");
      std::fflush(stdout);
      std::exit(EXIT_FAILURE);
    }
  }


  // Compute secondary range.
  {
    long newleft = 0L;
    long newright = 0L;
    long new_pat_length = cur_pat_length + max_block_size;
    refine_range(text, block_begin, block_psa, left, right,
        cur_pat_length, new_pat_length, pat, newleft, newright);
    left = newleft;
    right = newright;
    cur_pat_length = new_pat_length;
  }
  secondary_range[row][column] = std::make_pair(left, right);


  // Verify the secondary range.
  {
    long smaller = 0L;
    long equal = 0L;
    for (long j = block_begin; j < block_end; ++j) {
      long lcp = 0L;
      while (lcp < cur_pat_length && text[j + lcp] == pat[lcp]) ++lcp;
      if (lcp == cur_pat_length) ++equal;
      else if (text[j + lcp] < pat[lcp]) ++smaller;
    }
    long check_left = smaller;
    long check_right = smaller + equal;
    if (secondary_range[row][column] != std::make_pair(check_left, check_right)) {
      fprintf(stdout, "\nError: incorrect secondary range!\n");
      std::fflush(stdout);
      std::exit(EXIT_FAILURE);
    }
  }
}


//=============================================================================
// Variant 2: compute primary and secondary range for second to last column.
//=============================================================================
template<typename saidx_t>
void compute_ranges_2(unsigned char *text, long text_length, long text_beg, long supertext_length,
    bwtsa_t<saidx_t> *bwtsa, long max_block_size, background_block_reader *reader,
    std::pair<long, long> **primary_range, std::pair<long, long> **secondary_range, long row, long column) {
  long text_end = text_beg + text_length;
  long tail_length = supertext_length - text_end;
  long n_blocks = (text_length + max_block_size - 1) / max_block_size;
  long block_end = text_length - (n_blocks - 1 - row) * max_block_size;
  long block_begin = std::max(0L, block_end - max_block_size);
  long block_size = block_end - block_begin;
  long pat_start = text_length - (n_blocks - 1 - column) * max_block_size;
  unsigned char *pat = text + pat_start;
  bwtsa_t<saidx_t> *block_psa = bwtsa + block_begin;


  // Check that 0 <= row < column and column == n_blocks - 2 and pat_start + max_block_size == text_length.
  if (0 > row || row >= column || column != n_blocks - 2 || pat_start + max_block_size != text_length) {
    fprintf(stdout, "\nError: invariant in compute_ranges_2 failed.\n");
    std::fflush(stdout);
    std::exit(EXIT_FAILURE);
  }


  long left = 0L;
  long right = block_size;
  long cur_pat_length = 0L;


  // Compute primary range.
  {
    long newleft = 0L;
    long newright = 0L;
    long new_pat_length = max_block_size;
    refine_range(text, block_begin, block_psa, left, right,
        cur_pat_length, new_pat_length, pat, newleft, newright);
    left = newleft;
    right = newright;
    cur_pat_length = new_pat_length;
  }
  primary_range[row][column] = std::make_pair(left, right);


  // Verify the primary range.
  {
    long smaller = 0L;
    long equal = 0L;
    for (long j = block_begin; j < block_end; ++j) {
      long lcp = 0L;
      while (lcp < cur_pat_length && text[j + lcp] == pat[lcp]) ++lcp;
      if (lcp == cur_pat_length) ++equal;
      else if (text[j + lcp] < pat[lcp]) ++smaller;
    }
    long check_left = smaller;
    long check_right = smaller + equal;
    if (primary_range[row][column] != std::make_pair(check_left, check_right)) {
      fprintf(stdout, "\nError: incorrect primary range!\n");
      std::fflush(stdout);
      std::exit(EXIT_FAILURE);
    }
  }


  // Compute secondary range.
  long pat_length = cur_pat_length + std::min(tail_length, max_block_size);
  while (left != right && cur_pat_length < pat_length) {
    long next_chunk = std::min(reader->get_chunk_size(), pat_length - cur_pat_length);
    long new_pat_length = cur_pat_length + next_chunk;
    reader->wait(new_pat_length - max_block_size);

    long newleft = 0L;
    long newright = 0L;
    refine_range(text, block_begin, block_psa, left, right,
        cur_pat_length, new_pat_length, reader->m_data - max_block_size, newleft, newright);
    left = newleft;
    right = newright;
    cur_pat_length = new_pat_length;
  }
  secondary_range[row][column] = std::make_pair(left, right);
}



//=============================================================================
// Variant 3: compute primary and secondary range for the last column.
//=============================================================================
template<typename saidx_t>
void compute_ranges_3(unsigned char *text, long text_length, long text_beg, long supertext_length,
    bwtsa_t<saidx_t> *bwtsa, long max_block_size, multifile *tail_gt_begin_reversed, background_block_reader *reader,
    std::pair<long, long> **primary_range, std::pair<long, long> **secondary_range, long row, long column) {
  long text_end = text_beg + text_length;
  long tail_length = supertext_length - text_end;
  long n_blocks = (text_length + max_block_size - 1) / max_block_size;
  long block_end = text_length - (n_blocks - 1 - row) * max_block_size;
  long block_beg = std::max(0L, block_end - max_block_size);
  long block_size = block_end - block_beg;
  bwtsa_t<saidx_t> *block_psa = bwtsa + block_beg;
  long first_range_pat_length = std::min(max_block_size, tail_length);
  long pat_length = std::min(text_length + 1, tail_length);
  // Note: max_block_size <= text_length thus first_range_pat_length <= pat_length
  // Note: `reader' will read `pat_length' bytes.


  // Check that 0 <= row < colum and column == n_blocks - 1.
  if (0 > row || row >= column || column != n_blocks - 1) {
    fprintf(stdout, "\nError: invariant 1 in compute_ranges_3 failed.\n");
    std::fflush(stdout);
    std::exit(EXIT_FAILURE);
  }


  long left = 0L;
  long right = block_size;
  long cur_pat_length = 0L;


  // Compute the primary range.
  while (left != right && cur_pat_length < first_range_pat_length) {
    long next_chunk = std::min(reader->get_chunk_size(), first_range_pat_length - cur_pat_length);
    long new_pat_length = cur_pat_length + next_chunk;
    reader->wait(new_pat_length);

    long newleft = 0L;
    long newright = 0L;
    refine_range(text, text_length, tail_length, block_beg, block_psa, left, right,
        tail_gt_begin_reversed, cur_pat_length, new_pat_length, reader->m_data, newleft, newright);
    left = newleft;
    right = newright;
    cur_pat_length = new_pat_length;
  }
  primary_range[row][column] = std::make_pair(left, right);


  // Compute the secondary range.
  while (left != right && cur_pat_length < pat_length) {
    long next_chunk = std::min(reader->get_chunk_size(), pat_length - cur_pat_length);
    long new_pat_length = cur_pat_length + next_chunk;
    reader->wait(new_pat_length);

    long newleft = 0L;
    long newright = 0L;
    refine_range(text, text_length, tail_length, block_beg, block_psa, left, right,
        tail_gt_begin_reversed, cur_pat_length, new_pat_length, reader->m_data, newleft, newright);
    left = newleft;
    right = newright;
    cur_pat_length = new_pat_length;
  }
  secondary_range[row][column] = std::make_pair(left, right);
}



template<typename saidx_t>
void compute_block_rank_matrix(unsigned char *text, long text_length, 
    bwtsa_t<saidx_t> *bwtsa, long max_block_size, long /*max_threads*/,
    long text_beg, long supertext_length, std::string supertext_filename,
    multifile *tail_gt_begin_reversed, 
    background_block_reader *reader, long **block_rank_matrix) {
  long n_blocks = (text_length + max_block_size - 1) / max_block_size;

  std::pair<long, long> **primary_range = new std::pair<long, long>*[n_blocks];
  std::pair<long, long> **secondary_range = new std::pair<long, long>*[n_blocks];
  for (long j = 0; j < n_blocks; ++j) {
    primary_range[j] = new std::pair<long, long>[n_blocks];
    secondary_range[j] = new std::pair<long, long>[n_blocks];
  }


  for (long row = 0; row < n_blocks; ++row)
    for (long column = row + 1; column < n_blocks - 2; ++column)
      compute_ranges_1(text, text_length, bwtsa, max_block_size, primary_range, secondary_range, row, column);

  for (long row = 0; row < n_blocks - 2; ++row) {
    long column = n_blocks - 2;
    compute_ranges_2(text, text_length, text_beg, supertext_length, bwtsa, max_block_size, reader,
        primary_range, secondary_range, row, column);
  }


  //---------------------------------------------------------------------------
  // STEP 1: Start the threads computing ranges for the last column
  //---------------------------------------------------------------------------
  std::thread **threads_last_col = new std::thread*[n_blocks - 1];
  for (long row = 0; row + 1 < n_blocks; ++row) {
    long column = n_blocks - 1;
    threads_last_col[row] = new std::thread(compute_ranges_3<saidx_t>,
        text, text_length, text_beg, supertext_length,
        bwtsa, max_block_size, tail_gt_begin_reversed, reader,
        primary_range, secondary_range, row, column);
  }


  // Compute the last column
  for (long row = 0; row + 1 < n_blocks; ++row) threads_last_col[row]->join();
  for (long row = 0; row + 1 < n_blocks; ++row) block_rank_matrix[row][n_blocks - 1] = secondary_range[row][n_blocks - 1].first;
  for (long row = 0; row + 1 < n_blocks; ++row) delete threads_last_col[row];
  delete[] threads_last_col;



  //---------------------------------------------------------------------------
  // STEP 2: compute the remaining elements of the matrix, that is,
  //   block_rank_matrix[i][j] for 0 <= i < j < n_blocks - 1.
  //---------------------------------------------------------------------------

  // XXX for now we do it sequentially.
  for (long i = 0; i < n_blocks; ++i) {
    long block_end = text_length - (n_blocks - 1 - i) * max_block_size;
    long block_beg = std::max(0L, block_end - max_block_size);
    long block_size = block_end - block_beg;
    bwtsa_t<saidx_t> *block_psa = bwtsa + block_beg;

    for (long j = i + 1; j + 1 < n_blocks; ++j) {
      long suf_start = text_length - (n_blocks - 1 - j) * max_block_size;

      // Binary search.
      long left = -1;
      long right = block_size;
      while (left + 1 != right) {
        // Invariant: the answer is in the range (left, right].
        long mid = (left + right) / 2;
        if (compare_suffixes(text, text_length, suf_start, block_beg + block_psa[mid].sa,
              text_beg, supertext_length, supertext_filename)) {
          left = mid;
        } else {
          right = mid;
        }
      }

      // The answer is 'right'.
      block_rank_matrix[i][j] = right;
    }
  }
}

}  // inmem_sascan_private

#endif  // __INMEM_COMPUTE_BLOCK_RANK_MATRIX
