#ifndef __INMEM_COMPUTE_BLOCK_RANK_MATRIX
#define __INMEM_COMPUTE_BLOCK_RANK_MATRIX

#include <cstdio>
#include <cstdlib>
#include <string>

#include "bwtsa.h"
#include "../../multifile.h"

namespace inmem_sascan_private {

// Return true iff text[i..length) > text[j..length).
// We access text via pattern class.
bool em_suffix_compare(std::string filename, long length, long i, long j) {
  pattern isuf(filename, i);
  pattern jsuf(filename, j);

  long lcp = 0L;
  while (i + lcp < length && j + lcp < length && isuf[lcp] == jsuf[lcp])
    ++lcp;

  return (j + lcp == length || (i + lcp < length && isuf[lcp] > jsuf[lcp]));
}

// Return true iff text[i..length) > text[j..length).
// i > j
bool compare_suffixes(unsigned char *text, long text_length, long i, long j,
    long text_beg, long supertext_length, std::string supertext_filename) {
  long text_end = text_beg + text_length;
  bool has_tail = (text_end != supertext_length);
  long lcp = 0L;
  while (i + lcp < text_length && text[i + lcp] == text[j + lcp]) ++lcp;

//  return !(i + lcp == text_length || text[i + lcp] < text[j + lcp]);
  if (i + lcp == text_length)
    return (has_tail && em_suffix_compare(supertext_filename, supertext_length, text_end, text_beg + j + lcp));
  else return text[i + lcp] > text[j + lcp];
}

// Return true iff text[i..) (but we always stop the comparison
// at text_length) is smaller than pat[0..pat_length).
bool lcp_compare_2(unsigned char *text, long text_length, pattern &pat, long pat_length, long pat_absolute_beg,
  long supertext_length, long j, multifile_bit_stream_reader &reader) {
  long lcp = 0;
  while (lcp < pat_length && j + lcp < text_length && pat[lcp] == text[j + lcp]) ++lcp;

  return (
      (lcp == pat_length) ||
      (j + lcp < text_length && pat[lcp] < text[j + lcp]) ||
      (j + lcp == text_length && !(reader.access(supertext_length - pat_absolute_beg - lcp)))
  );
}

template<typename saidx_t, unsigned pagesize_log>
void compute_block_rank_matrix(unsigned char *text, long text_length, 
    bwtsa_t<saidx_t> *bwtsa, long max_block_size, long /*max_threads*/,
    long text_beg, long supertext_length, std::string supertext_filename,
    multifile * tail_gt_begin_reversed, long **block_rank_matrix) {
  long text_end = text_beg + text_length;
  bool has_tail = (text_end != supertext_length);
  long n_blocks = (text_length + max_block_size - 1) / max_block_size;

  //---------------------------------------------------------------------------
  // STEP 1: compute the last column of the matrix.
  //---------------------------------------------------------------------------
  if (!has_tail) {
    for (long j = 0; j + 1 < n_blocks; ++j)
      block_rank_matrix[j][n_blocks - 1] = 0;
  } else {
#if 0
    fprintf(stderr, "\nError in compute_block_rank_matrix: this is currently not implemented!\n");
    std::exit(EXIT_FAILURE);
#else
    pattern pat(supertext_filename, text_end);
    long pat_length = supertext_length - text_end;

    multifile_bit_stream_reader reader(tail_gt_begin_reversed);

    for (long j = 0; j + 1 < n_blocks; ++j) {
      long block_end = text_length - (n_blocks - 1 - j) * max_block_size;
      long block_beg = std::max(0L, block_end - max_block_size);
      long block_size = block_end - block_beg;

      bwtsa_t<saidx_t> *block_psa = bwtsa + block_beg;

      long left = -1L;
      long right = block_size;

      while (left + 1 != right) {
        long mid = (left + right) / 2;
        if (lcp_compare_2(text, text_length, pat, pat_length, text_end, supertext_length,
          block_beg + block_psa[mid].sa, reader)) right = mid;
        else left = mid;
      }

      block_rank_matrix[j][n_blocks - 1] = right;
    }
#endif
  }

  //---------------------------------------------------------------------------
  // STEP 2: compute the remaining elements of the matrix, that is,
  //   block_rank_matrix[i][j] for 0 <= i < j < n_blocks - 1.
  //---------------------------------------------------------------------------

  // XXX for now we do it sequentially.
  for (long i = 0; i < n_blocks; ++i) {
    long block_end = text_length - (n_blocks - 1 - i) * max_block_size;
    long block_beg = std::max(0L, block_end - max_block_size);
    long block_size = block_end - block_beg;
    bwtsa_t<saidx_t> *block_psa = bwtsa + block_beg;

    for (long j = i + 1; j + 1 < n_blocks; ++j) {
      long suf_start = text_length - (n_blocks - 1 - j) * max_block_size;

      // Binary search.
      long left = -1;
      long right = block_size;
      while (left + 1 != right) {  // while range size is > 1.
        // Invariant: the answer is in the range (left, right].
        long mid = (left + right) / 2;
        if (compare_suffixes(text, text_length, suf_start, block_beg + block_psa[mid].sa,
              text_beg, supertext_length, supertext_filename)) {
          left = mid;
        } else {
          right = mid;
        }
      }

      // The answer is 'right'.
      block_rank_matrix[i][j] = right;
    }
  }
}

}  // inmem_sascan_private

#endif  // __INMEM_COMPUTE_BLOCK_RANK_MATRIX
