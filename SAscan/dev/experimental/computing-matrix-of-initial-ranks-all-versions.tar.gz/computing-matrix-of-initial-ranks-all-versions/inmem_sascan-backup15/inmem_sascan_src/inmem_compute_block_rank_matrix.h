// Note: this class creates more threads than blocks
// Right now I think the number of threads will be around
// 3 times the number of blocks. So here we have a similar
// situation as with divsufsort -- we use as many threads
// as there are blocks.

#ifndef __INMEM_COMPUTE_BLOCK_RANK_MATRIX
#define __INMEM_COMPUTE_BLOCK_RANK_MATRIX

#include <cstdio>
#include <cstdlib>
#include <string>

#include "bwtsa.h"
#include "background_block_reader.h"
#include "../../multifile.h"

namespace inmem_sascan_private {

// Return true iff text[i..length) > text[j..length).
// We access text via pattern class.
bool em_suffix_compare(std::string filename, long length, long i, long j) {
  pattern isuf(filename, i);
  pattern jsuf(filename, j);

  long lcp = 0L;
  while (i + lcp < length && j + lcp < length && isuf[lcp] == jsuf[lcp])
    ++lcp;

  return (j + lcp == length || (i + lcp < length && isuf[lcp] > jsuf[lcp]));
}

// Return true iff text[i..length) > text[j..length).
// i > j
bool compare_suffixes(unsigned char *text, long text_length, long i, long j,
    long text_beg, long supertext_length, std::string supertext_filename) {
  long text_end = text_beg + text_length;
  bool has_tail = (text_end != supertext_length);
  long lcp = 0L;
  while (i + lcp < text_length && text[i + lcp] == text[j + lcp]) ++lcp;

  if (i + lcp == text_length)
    return (has_tail && em_suffix_compare(supertext_filename, supertext_length, text_end, text_beg + j + lcp));
  else return text[i + lcp] > text[j + lcp];
}

int lcp_compare_2(unsigned char *text, long text_length, unsigned char *pat, long pat_length,
    long gt_begin_length, long j, multifile_bit_stream_reader &rev_gt_begin_reader, long &lcp) {
  while (lcp < pat_length && j + lcp < text_length && pat[lcp] == text[j + lcp]) ++lcp;

  if (lcp == pat_length) return 0;
  if ((j + lcp < text_length && pat[lcp] < text[j + lcp]) ||
      (j + lcp >= text_length && !(rev_gt_begin_reader.access(gt_begin_length - (text_length - j)))))
    return -1;
  else return 1;
}

template<typename saidx_t>
void refine_range(unsigned char *text, long text_length,
    long tail_gt_begin_reversed_length,
    long block_beg, bwtsa_t<saidx_t> *block_psa,
    long left, long right,
    multifile *tail_gt_begin_reversed,
    long old_pat_length, long pat_length, unsigned char *pat,
    long &newleft, long &newright) {  // output
  multifile_bit_stream_reader reader(tail_gt_begin_reversed);

  long low = left - 1;
  long high = right;
  long llcp = old_pat_length;
  long rlcp = old_pat_length;

  // static const long min_discrepancy = /*(1L << 16)*/1L;
  // static const long balancing_constant = /*64L*/1L;
  // XXX replace the above
  long min_discrepancy = utils::random_long(0L, 10L);
  long balancing_constant = utils::random_long(1L, 10L);

  while (low + 1 != high) {
    // Invariant: newleft is in the range (low, high].

    // Compute mid.
    // Valid values for mid are: low + 1, .., high - 1.
    long mid = 0L;
    if (llcp + min_discrepancy < rlcp) {
      // Choose the pivot that split the range into two parts of sizes
      // with ratio equal to logd / d.
      long d = rlcp - llcp;
      long logd = utils::log2ceil(d);
      mid = low + 1 + ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
    } else if (rlcp + min_discrepancy < llcp) {
      long d = llcp - rlcp;
      long logd = utils::log2ceil(d);
      mid = high - 1 - ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
    } else {
      // Discrepancy between lcp values is small, use standard binary search.
      mid = (low + high) / 2;
    }

    long lcp = std::min(llcp, rlcp);

    if (lcp_compare_2(text, text_length, pat, pat_length, tail_gt_begin_reversed_length,
          block_beg + block_psa[mid].sa, reader, lcp) <= 0) {
      high = mid;
      rlcp = lcp;
    } else {
      low = mid;
      llcp = lcp;
    }
  }

  newleft = high;

  if (rlcp < pat_length) newright = newleft;
  else {
    high = right;
    rlcp = old_pat_length;

    while (low + 1 != high) {
      // Invariant: newright is in the range (low, high].

      // Compute mid.
      // Valid values for mid are: low + 1, .., high - 1.
      long mid = 0L;
      if (llcp + min_discrepancy < rlcp) {
        // Choose the pivot that split the range into two parts of sizes
        // with ratio equal to logd / d.
        long d = rlcp - llcp;
        long logd = utils::log2ceil(d);
        mid = low + 1 + ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
      } else if (rlcp + min_discrepancy < llcp) {
        long d = llcp - rlcp;
        long logd = utils::log2ceil(d);
        mid = high - 1 - ((high - low - 1) * balancing_constant * logd) / (d + balancing_constant * logd);
      } else {
        // Discrepancy between lcp values is small, use standard binary search.
        mid = (low + high) / 2;
      }

      long lcp = std::min(llcp, rlcp);

      if (lcp_compare_2(text, text_length, pat, pat_length, tail_gt_begin_reversed_length,
            block_beg + block_psa[mid].sa, reader, lcp) < 0) {
        high = mid;
        rlcp = lcp;
      } else {
        low = mid;
        llcp = lcp;
      }
    }

    newright = high;
  }

  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  // NOTE: the range returned by this function is NOT the range of suffixes
  // starting in the block that has pat[0..pat_length) as a prefix. This would
  // only be the case, if we didn't use gt_begin for the tail.
  //
  // Instead what we get is a subrange of the above. More specifically, we get
  // the range of suffixes starting inside the block that have pat[0..pat_length)
  // as a prefix *and we could not determine whether they are larger than the
  // whole pattern (of length tail_gt_begin_reversed_legth) or not*.
  //
  // This is because we stop the symbol comparisons (when computing lcp value)
  // at the end of the text and then use gt_begin for the tail. This may cause
  // the we classify the suffix with pat[0..pat_length) as a prefix already at
  // this point as larger than the whole pattern because gt_begin encodes that
  // information.
  //
  // This effect makes thus function difficult to debug, because there is no
  // well defined output of the range refinement.
  //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
}


template<typename saidx_t>
void compute_matrix_last_column_aux(unsigned char *text, long text_length,
    long text_beg, long supertext_length,
    long block_beg, long block_end, bwtsa_t<saidx_t> *block_psa,
    multifile *tail_gt_begin_reversed,
    background_block_reader *reader,
    long &result) {

  long text_end = text_beg + text_length;
  long block_size = block_end - block_beg;
  long tail_length = supertext_length - text_end;
  long pat_length = std::min(text_length + 1, tail_length);
  // Invariant: `reader' will read `pat_length' bytes.

  long left = 0L, right = block_size;
  long cur_pat_prefix_len = 0L;

  while (left != right && cur_pat_prefix_len < pat_length) {
    // Extend the prefix pattern.
    long next_chunk = std::min(reader->get_chunk_size(), pat_length - cur_pat_prefix_len);
    long new_pat_prefix_len = cur_pat_prefix_len + next_chunk;

    // Wait until enough symbols is read by the background reader.
    reader->wait(new_pat_prefix_len);

    // Refine the range (compute new range boundaries).
    long newleft = 0L, newright = 0L;
    refine_range(text, text_length,
        tail_length,
        block_beg, block_psa,
        left, right,
        tail_gt_begin_reversed,
        cur_pat_prefix_len, new_pat_prefix_len, reader->m_data,
        newleft, newright);

    // Update range boundaries.
    left = newleft;
    right = newright;
    cur_pat_prefix_len = new_pat_prefix_len;
  }

  result = left;
}

template<typename saidx_t, unsigned pagesize_log>
void compute_block_rank_matrix(unsigned char *text, long text_length, 
    bwtsa_t<saidx_t> *bwtsa, long max_block_size, long /*max_threads*/,
    long text_beg, long supertext_length, std::string supertext_filename,
    multifile * tail_gt_begin_reversed, 
    background_block_reader *reader, long **block_rank_matrix) {
  long text_end = text_beg + text_length;
  bool has_tail = (text_end != supertext_length);
  long n_blocks = (text_length + max_block_size - 1) / max_block_size;


  //---------------------------------------------------------------------------
  // STEP 1: compute the last column of the matrix.
  // Note: `reader' already at this point is reading the next block.
  //---------------------------------------------------------------------------
  if (!has_tail) {
    for (long j = 0; j + 1 < n_blocks; ++j)
      block_rank_matrix[j][n_blocks - 1] = 0;
  } else {
    std::thread **threads = new std::thread*[n_blocks - 1];
    for (long t = 0; t + 1 < n_blocks; ++t) {
      long block_end = text_length - (n_blocks - 1 - t) * max_block_size;
      long block_beg = std::max(0L, block_end - max_block_size);
      bwtsa_t<saidx_t> *block_psa = bwtsa + block_beg;

      threads[t] = new std::thread(compute_matrix_last_column_aux<saidx_t>,
          text, text_length, text_beg, supertext_length,
          block_beg, block_end, block_psa, tail_gt_begin_reversed, reader,
          std::ref(block_rank_matrix[t][n_blocks - 1]));
    }

    for (long t = 0; t + 1 < n_blocks; ++t) threads[t]->join();
    for (long t = 0; t + 1 < n_blocks; ++t) delete threads[t];
    delete[] threads;
  }

  //---------------------------------------------------------------------------
  // STEP 2: compute the remaining elements of the matrix, that is,
  //   block_rank_matrix[i][j] for 0 <= i < j < n_blocks - 1.
  //---------------------------------------------------------------------------

  // XXX for now we do it sequentially.
  for (long i = 0; i < n_blocks; ++i) {
    long block_end = text_length - (n_blocks - 1 - i) * max_block_size;
    long block_beg = std::max(0L, block_end - max_block_size);
    long block_size = block_end - block_beg;
    bwtsa_t<saidx_t> *block_psa = bwtsa + block_beg;

    for (long j = i + 1; j + 1 < n_blocks; ++j) {
      long suf_start = text_length - (n_blocks - 1 - j) * max_block_size;

      // Binary search.
      long left = -1;
      long right = block_size;
      while (left + 1 != right) {
        // Invariant: the answer is in the range (left, right].
        long mid = (left + right) / 2;
        if (compare_suffixes(text, text_length, suf_start, block_beg + block_psa[mid].sa,
              text_beg, supertext_length, supertext_filename)) {
          left = mid;
        } else {
          right = mid;
        }
      }

      // The answer is 'right'.
      block_rank_matrix[i][j] = right;
    }
  }
}

}  // inmem_sascan_private

#endif  // __INMEM_COMPUTE_BLOCK_RANK_MATRIX
