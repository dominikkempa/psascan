#ifndef __BALANCED_MERGE_H
#define __BALANCED_MERGE_H

#include <vector>

#include "bitvector.h"
#include "inmem_gap_array.h"
#include "inmem_compute_gap.h"
#include "inmem_bwt_from_sa.h"
#include "parallel_merge.h"
#include "pagearray.h"
#include "bwtsa.h"


// Returns i0, or -1 if unknown.
template<typename saidx_t, unsigned pagesize_log>
pagearray<bwtsa_t<saidx_t>, pagesize_log> *balanced_merge(unsigned char *text,
    long text_length, bwtsa_t<saidx_t> *bwtsa, bitvector *gt,
    long max_block_size, long range_beg, long range_end, long max_threads,
    bool need_gt, long &result_i0) {
  static const unsigned pagesize_mask = (1U << pagesize_log) - 1;

  long range_size = range_end - range_beg;

  if (range_size == 1) {
    long block_beg = max_block_size * range_beg;
    long block_end = std::min(block_beg + max_block_size, text_length);
    long block_size = block_end - block_beg;

    fprintf(stderr, "Computing BWT for block [%ld..%ld): ", block_beg, block_end);
    long double start = utils::wclock();

    //
    // increase values in the SA
    //
    for (long i = block_beg; i < block_end; ++i)
      bwtsa[i].sa += block_beg;

    bwt_from_sa_into_dest<saidx_t>(text, block_beg, block_end, bwtsa, max_threads, result_i0);

    // decrease them again.
    for (long i = block_beg; i < block_end; ++i) {
      long val = bwtsa[i].sa;
      val -= block_beg;
      bwtsa[i].sa = val;
    }

    fprintf(stderr, "%.2Lf\n", utils::wclock() - start);

    pagearray<bwtsa_t<saidx_t>, pagesize_log> *bwtsa_pagearray = new pagearray<bwtsa_t<saidx_t>, pagesize_log>(bwtsa + block_beg,
        bwtsa + block_beg + block_size);
    return bwtsa_pagearray;
  }

  // Split blocks almost equally into two groups.
  long lrange_size = /*(range_size + 1) / 2*/range_size - 1;
  long rrange_size = range_size - lrange_size;

  long lrange_beg = range_beg;
  long lrange_end = range_beg + lrange_size;
  long rrange_beg = lrange_end;
  long rrange_end = rrange_beg + rrange_size;

  long lbeg = lrange_beg * max_block_size;
  long rbeg = rrange_beg * max_block_size;
  long lend = rbeg;
  long rend = std::min(rbeg + rrange_size * max_block_size, text_length);
  long lsize = lend - lbeg;
  long rsize = rend - rbeg;

  // Compute partial sa for the blocks recursively.
  long left_i0;
  pagearray<bwtsa_t<saidx_t>, pagesize_log> *l_bwtsa_pagearray = 
      balanced_merge<saidx_t, pagesize_log>(text, text_length, bwtsa, gt,
      max_block_size, lrange_beg, lrange_end, max_threads, need_gt, left_i0);

  // right
  long right_i0;
  pagearray<bwtsa_t<saidx_t>, pagesize_log> *r_bwtsa_pagearray =
      balanced_merge<saidx_t, pagesize_log>(text, text_length, bwtsa, gt,
      max_block_size, rrange_beg, rrange_end, max_threads, true, right_i0);

  // Merge partial suffix arrays.
  fprintf(stderr, "Merging blocks [%ld..%ld) and [%ld..%ld):\n", lbeg, lend, rbeg, rend);
  long double start = utils::wclock();

  inmem_gap_array *gap;
  fprintf(stderr, "  Computing gap:\n");
  long double start1 = utils::wclock();
  inmem_compute_gap<saidx_t, pagesize_log>(text, text_length, lbeg, lsize, rsize, l_bwtsa_pagearray,
      gt, gap, max_threads, need_gt, left_i0, (1L << 21));
  fprintf(stderr, "  Time: %.2Lf\n", utils::wclock() - start1);

  fprintf(stderr, "  Merging partial SAs:  ");
  start1 = utils::wclock();

  //
  // manually increase values of the right partial SABWT by lsize
  //
  for (long i = 0; i < rsize; ++i)
    r_bwtsa_pagearray->m_pageindex[i >> pagesize_log][i & pagesize_mask].sa += lsize;

  r_bwtsa_pagearray->m_pageindex[right_i0 >> pagesize_log][right_i0 & pagesize_mask].bwt = text[rbeg - 1]; // !!!
  // XXX this shold be an operator [] in a pagearray that returns a reference (rather than the access method).

  long delta_i0;
  pagearray<bwtsa_t<saidx_t>, pagesize_log> *merged_bwtsa_pagearray = parallel_merge(l_bwtsa_pagearray,
      r_bwtsa_pagearray, gap, max_threads, left_i0, delta_i0);
  delete l_bwtsa_pagearray;
  delete r_bwtsa_pagearray;

  fprintf(stderr, "total: %.2Lf\n", utils::wclock() - start1);

  fprintf(stderr, "  Deleting gap: ");
  start1 = utils::wclock();
  delete gap;
  fprintf(stderr, "%.2Lf\n", utils::wclock() - start1);

  fprintf(stderr, "Time: %.2Lf\n", utils::wclock() - start);
  result_i0 = left_i0 + delta_i0;

  return merged_bwtsa_pagearray;
}

#endif  // __BALANCED_MERGE_H
