#include <cstdio>
#include <cstring>
#include <ctime>
#include <algorithm>
#include <thread>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "divsufsort.h"
#include "divsufsort64.h"
#include "bitvector.h"
#include "multifile_bitvector.h"
#include "utils.h"
#include "io_streamer.h"
#include "inmem_sascan.h"


void compute_gt_begin_reversed(unsigned char *text, long text_length, bitvector *gt_begin_reversed) {
  long i = 1, el = 0;
  while (i < text_length) {
    while (i + el < text_length && text[i + el] == text[el]) ++el;
    if (i + el < text_length && text[i + el] > text[el])
      gt_begin_reversed->set(text_length - i);

    el = 0;
    ++i;
  }
}

void test(unsigned char *supertext, long supertext_length,
    long text_beg, long text_end, long max_threads) {

  // Sort supertext using divsufsort.
  int *supertext_sa = (int *)malloc(supertext_length * sizeof(int));
  divsufsort(supertext, supertext_sa, (int)supertext_length);

  // Separate the ordering of the suffixes of text (correct answer).
  long text_length = text_end - text_beg;
  int *correct_answer = (int *)malloc(text_length * sizeof(int));
  long ptr = 0;
  for (long i = 0; i < supertext_length; ++i)
    if (text_beg <= supertext_sa[i] && supertext_sa[i] < text_end)
      correct_answer[ptr++] = supertext_sa[i] - text_beg;

  // Compute tail_gt_begin_reversed.
  unsigned char *tail = supertext + text_end;
  long tail_length = supertext_length - text_end;
  bitvector tail_gt_begin_reversed_bv(tail_length, max_threads);
  compute_gt_begin_reversed(tail, tail_length, &tail_gt_begin_reversed_bv);

  // Store tail_gt_begin_reversed on disk as a multifile bitvector.
  multifile *tail_gt_begin_reversed_multifile = new multifile();
  ptr = 0;
  while (ptr < tail_length) {
    long left = tail_length - ptr;
    long chunk = utils::random_long(1L, left);
   
    // Store bits [ptr..ptr+chunk) from tail_gt_begin_reversed_bv into one file.
    std::string chunk_filename = "gt_begin_reversed_bv" + utils::random_string_hash();
    bit_stream_writer *writer = new bit_stream_writer(chunk_filename);
    for (long j = ptr; j < ptr + chunk; ++j)
      writer->write(tail_gt_begin_reversed_bv.get(j));
    delete writer;

    // Add this file to tail_gt_begin_reversed_multifile.
    tail_gt_begin_reversed_multifile->add_file(ptr, ptr + chunk, chunk_filename);
    
    ptr += chunk;
  }

  // Write supertext to file.
  std::string supertext_filename = "supertext.txt";
  stream_writer<unsigned char> *supertext_writer = new stream_writer<unsigned char>(supertext_filename);
  for (long i = 0; i < supertext_length; ++i)
    supertext_writer->write(supertext[i]);
  delete supertext_writer;






  // Run the tested algorithm.
  unsigned char *text = supertext + text_beg;
  unsigned char *bwtsa = (unsigned char *)malloc(text_length * (1 + sizeof(int)));
  int *computed_sa = (int *)bwtsa;
  inmem_sascan<int, 2>(text, text_length, bwtsa, max_threads, false, false, NULL, -1, text_beg, text_end, supertext_length,
      supertext_filename, tail_gt_begin_reversed_multifile);





  // Compare answers.
  if (!std::equal(computed_sa, computed_sa + text_length, correct_answer)) {
    fprintf(stdout, "Error:\n");
    fprintf(stdout, "\tsupertext_length = %ld\n", supertext_length);
    fprintf(stdout, "\tmax threads = %ld\n", max_threads);
    fprintf(stdout, "\tsupertext = ");
    for (long j = 0; j < supertext_length; ++j)
      fprintf(stdout, "%c", supertext[j]);
    fprintf(stdout, "\n");
    fprintf(stdout, "\ttext_beg = %ld\n", text_beg);
    fprintf(stdout, "\ttext_end = %ld\n", text_end);
    fprintf(stdout, "\ttail_gt_begin_reversed_bv = ");
    for (long j = 0; j < tail_length; ++j)
      fprintf(stdout, "%ld", (long)tail_gt_begin_reversed_bv.get(j));
    fprintf(stdout, "\n");
    fprintf(stdout, "\tsupertext sa = ");
    for (long j = 0; j < supertext_length; ++j)
      fprintf(stdout, "%ld ", (long)supertext_sa[j]);
    fprintf(stdout, "\n");
    fprintf(stdout, "\tcorrect answer = ");
    for (long j = 0; j < text_length; ++j)
      fprintf(stdout, "%ld ", (long)correct_answer[j]);
    fprintf(stdout, "\n");
    fprintf(stdout, "\tcomputed answer = ");
    for (long j = 0; j < text_length; ++j)
      fprintf(stdout, "%ld ", (long)computed_sa[j]);
    fprintf(stdout, "\n");
    std::fflush(stdout);

    std::exit(EXIT_FAILURE);
  }




  delete tail_gt_begin_reversed_multifile; // also deletes files
  free(bwtsa);
  free(correct_answer);
  free(supertext_sa);
}


void test_random(int testcases, long max_length, int max_sigma) {
  fprintf(stdout,"TEST, testcases = %d, max_n = %ld, max_sigma = %d\n",
      testcases, max_length, max_sigma);
  unsigned char *supertext = new unsigned char[max_length + 1];

  for (int tc = 0; tc < testcases; ++tc) {
    // Print progress information.
    fprintf(stdout,"%d (%.2Lf%%)\r", tc, (tc * 100.L) / testcases);
    std::fflush(stdout);




    // Generate string.
    long supertext_length = utils::random_long(1, max_length);
    int sigma = utils::random_int(2, max_sigma);
    if (max_sigma <= 26) utils::fill_random_letters(supertext, supertext_length, sigma);
    else utils::fill_random_string(supertext, supertext_length, sigma);
    long max_threads = utils::random_long(1, 50);
    long text_beg = utils::random_long(0, supertext_length - 1);
    long text_end = utils::random_long(text_beg + 1, supertext_length);



    /*long supertext_length = 325;
    long max_threads = 16;
    supertext[0] = 0;
    strcpy((char *)supertext, "adbbddacdcdacacccddcbdccbaaaabcaadcadcccabccbaaddabadadbadbaadabdcbcadaaacdbcdbbdccdcbacabcaadbdbcbcbbcbdbdbbadacbdbcddcaccbbaacccaaddbdaaabadcdabacbdabbdccddbbbbbaaddbdacadadacdcdcdaacdcbcdcdbadbddccdbccbbcdabcdaddccbdabbdcbcdabcdadbdadbadccccbbaddddabcccbbdcdcdcdcdcddccbaadcbcbacbbadabadaabdcabbdaabccbdbdadaabbccacdbbdbcc");
    long text_beg = 125;
    long text_end = 269;*/


    // Run the test on generated string.
    test(supertext, supertext_length, text_beg, text_end, max_threads);
  }

  // Clean up.
  delete[] supertext;
}


int main() {
  // std::srand(std::time(0) + getpid());

  // Redirect stdout to /dev/null
  // int redir = open("/dev/null", O_WRONLY);
  // dup2(redir, 2);
  // close(redir);

//  test_random(10000,   10,      5);
//  test_random(10000,   10,      255);
  test_random(50000,   500,    5);
  test_random(50000,   500,    255);
  test_random(1000,    100000,  5);
  test_random(1000,    100000,  255);
  test_random(1000,    1000000, 5);
  test_random(1000,    1000000, 255);

  fprintf(stdout,"All tests passed.\n");
  std::fflush(stdout);
}

